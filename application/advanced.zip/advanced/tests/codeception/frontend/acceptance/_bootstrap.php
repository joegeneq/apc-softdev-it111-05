<?php
new yii\web\Application(require(dirname(dirname(__DIR__)) . '/config/frontend/acceptance.php'));
